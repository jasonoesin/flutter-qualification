package com.example.qualif

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
